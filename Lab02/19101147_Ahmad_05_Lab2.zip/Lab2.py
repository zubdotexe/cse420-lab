with open('Lab2_input.txt', 'r') as file:
    file = file.readlines()

    j = 0
    for line in file:

        line = line.strip('\n')
        state = 0 
        none = 0
        i = 0
        j += 1

        if((line.startswith('https://www.') or line.startswith('http://www.') or line.startswith('www.')) and 
        line.endswith('.com') or line.endswith('.edu') or line.endswith('.org')):
            
            if(line.startswith('https://www.')):
                line = line.strip('https://www.')
            elif(line.startswith('http://www.')):
                line = line.strip('http://www.')
            else:
                line = line.strip('www.')

            while True:

                if(state == 0):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalnum()):
                            state = 1
                        else:
                            state = 4
                        i += 1
              
                if(state == 1):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalnum()):
                            state = 1
                        elif(c == '.'):
                            state = 2
                        i += 1
            
                if(state == 2):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalpha()):
                            state = 3
                        else:
                            state = 4
                        i += 1
              
                if(state == 3):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalpha()):
                            state = 3
                        else:
                            state = 4
                        i += 1

                if(state == 4):
                    none += 1
                    break
              
                if(state == 3 and i == len(line)):
                    print(f"Web, {j}")
                    break
                
                elif(i == len(line)):
                    none += 1
                    break
                
        else:                        
            while True:

                if(state == 0):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalpha()):
                            state = 1
                        else:
                            state = 6
                        i += 1 
                    
                if(state == 1):
                    if(i < len(line)):
                        c = line[i]

                        if(c == '@'):
                            state = 2
                        else:
                            state = 1
                        i += 1
                    
                if(state == 2):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalpha()):
                            state = 3
                        else:
                            state = 6                
                        i += 1
                    
                if(state == 3):
                    if(i < len(line)):
                        c = line[i]

                        if(c == '.'):
                            state = 4
                        elif(c.isalpha()):
                            state = 3
                        else:
                            state = 6
                        i += 1
                    
                if(state == 4):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalpha()):
                            state = 5
                        else:
                            state = 6
                        i += 1
                    
                if(state == 5):
                    if(i < len(line)):
                        c = line[i]

                        if(c.isalpha()):
                            state = 5
                        else:
                            state = 6
                        i += 1
                    
                if(state == 6):
                    none += 1
                    break

                if(state == 5 and i == len(line)):
                    print(f"Email, {j}")
                    break

                elif(i == len(line)):
                    none += 1
                    break

        if(none > 0):
            print(f"Neither email nor web, {j}")        

            